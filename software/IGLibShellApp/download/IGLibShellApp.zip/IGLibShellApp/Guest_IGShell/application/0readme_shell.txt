﻿
This directory contains shell that enables running pre-installed commands. 

Files in this directory are not meant to be modified, except for adding additional
embedded command-line applications to AppIGShell.

