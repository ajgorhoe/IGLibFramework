﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace IG.App
{
    
    public static partial class ProgramHashGui
    {

        /// <summary>Entry point of the GUI-based file hashing application.</summary>
        /// <param name="args">Application arguments.</param>
        [STAThread]
        public static void Main(string[] args)
        {
            MainHashGui(args);
        }

    }


}
