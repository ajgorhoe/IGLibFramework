﻿
This is an IGLib official shell application.

Default directory:  ../../../../../../../../workspaceprojects/00tests/examples  

C Example command-line arguments:

C 2D parametric plot (Lissajous curves)
Interactive Internal IG.Script.ScriptGraphics2dBase Graph CurvePlotLissajous 5 4

C Executing a system command ("dir" in this case):
Interactive Sys dir

C Launch a file hash calculation form:
Internal IG.Script.AppExtBase Crypto HashForm

C Run cryptographic utility - calculation of file hashes:
Internal IG.Script.AppBase Crypto CheckSum -t MD5 -o hashes.MD5 app.cmd examples.cmd excrypto.cmd 




