﻿
This is application project for the IGLib Shell applications and programs. 
It contains the following items:
  - Minimalistic main program that only loads the application script from a library and runs it.
  - The "data" directory where basic data is located that is necessary for function of the code. Only small
    amounts of data can be put into this directory. The directory is synchronized with the SVN repository.
  - The "testdata" directory that is used for generated data. This directory is not synchronized
    with the SVN repository and must not contain data that is crucial for function of the code. Large
	amounts of data can be put into this directory.

This project is constructed according to the IGLib's minimal application standards. 

************ NAVODILA
V data/ExamplesFerdo.cmd v projektu so opisani načini, kako zaženeš svoje in druge programe.
Kateri program poženeš, določiš z argumenti ukazne vrstice, s katerimi poženeš program. Te najlažje
kar skopiraš iz 0readme_guest_ferdo_app.txt. Argumente ukazne vrstice pri poganjanju programa
nastaviš tako, da z desno klikneš ne ime svojega projekta (Guest_Ferdo_App), klikneš na properties,
izbereš zavihek "Properties" ter navedeš s presledkom ločene argumente pod "Command line arguments".
Trenutno sta inštalirana dva glavna programa, ki ju kličeš z ukazoma FerdoMain in FerdoTest. Z nizom ####
so označena mesta, kjer je izhodiščna koda teh dvah programov.

Svoje programe dodajaš v datoteki application/AppFerdo.cs.

V AppIgorGresovnik.cs je nekaj koristnih primerov, recimo za grafiko.




