
This directory contains various example scripts for cryptographic tools.

In order to run the commands that are listed in scripts, you must first run
any IGLib - based shell application in interactive mode (eg. shellext.exe or 
igs.exe, whichever you posess). Then you can just copy commands into command
prompt and press enter in order to execute them. A basic IGLib shell can be 
downloaded at 
  http://www2.arnes.si/~ljc3m2/igor/software/IGLibShellApp/

For example, fi you have igs.exe, follow the procedure below:
  1. in system command prompt, type
      igs.exe Interactive
    and press <Enter>.
  2. Copy or type the desired command into the shell prompt, e.g.
      Cmd> Internal IG.Script.ScriptGraphics2dBase Graph SinePlots 3 200
    and press <Enter>.
You can copy and execute any command from command scripts (extension .cmd).
You can also UNCOMMENT arbitrary number of commands and run the complete 
script by executing 'Run <script name>', e.g.
    Cmd> Run excrypto.cmd

