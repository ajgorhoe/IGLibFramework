
Sendigence readme:

* Installation:
Copy this directory to any appropriate location. Then copy the files from
the bin directory to some directory that is included in the system path.

* Running:
Run the program interactively by typing "sendigence" in the command prompt 
(a terminal window) and predding <Enter>.

*License
Sendigence is a freeware.
License information is included in documentation.

* Third party software:
The sendEmail program is included in the distribution. For terms of use and
other information, see the bin/sendEmail_readme.txt.

* Further information:
See program home page at 
  http://www2.arnes.si/~ljc3m2/igor/sendigence/


